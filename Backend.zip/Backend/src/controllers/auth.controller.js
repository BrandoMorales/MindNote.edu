import { db } from "../config/db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// ==========================
// REGISTRO
// ==========================
export const register = async (req, res) => {
  try {
    const { nombre, email, password, rol, claveAdmin } = req.body;

    if (!nombre || !email || !password || !rol) {
      return res.status(400).json({ msg: "Todos los campos son obligatorios" });
    }

    const [existing] = await db.query(
      "SELECT * FROM usuarios WHERE email = ?",
      [email]
    );

    if (existing.length > 0) {
      return res.status(400).json({ msg: "El correo ya está registrado" });
    }

    // Validación de admin
    if (rol === "administrador" && claveAdmin !== process.env.ADMIN_KEY) {
      return res.status(400).json({ msg: "Clave de administrador incorrecta" });
    }

    const hashed = bcrypt.hashSync(password, 10);

    const [result] = await db.query(
      "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)",
      [nombre, email, hashed, rol]
    );

    const token = jwt.sign(
      { id: result.insertId, rol },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    return res.json({
      msg: "Registro exitoso",
      user: { id: result.insertId, nombre, email, rol },
      token
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Error en el servidor" });
  }
};

// ==========================
// LOGIN
// ==========================
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await db.query(
      "SELECT * FROM usuarios WHERE email = ?",
      [email]
    );

    if (rows.length === 0) {
      return res.status(400).json({ msg: "Credenciales incorrectas" });
    }

    const user = rows[0];

    const valid = bcrypt.compareSync(password, user.password);
    if (!valid) {
      return res.status(400).json({ msg: "Credenciales incorrectas" });
    }

    const token = jwt.sign(
      { id: user.id, rol: user.rol },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    return res.json({
      msg: "Login exitoso",
      user: {
        id: user.id,
        nombre: user.nombre,
        email: user.email,
        rol: user.rol
      },
      token
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Error en el servidor" });
  }
};
